#!/usr/bin/env bash
set -euo pipefail

# setup_local_db.sh
# Crea un rol de PostgreSQL, crea la base de datos, carga el esquema (apex-unsis-snkc.sql)
# y ejecuta scripts de seed (scripts/seed_carreras.sql si existe).
# Además genera un archivo .env en la raíz del repo con las variables DB_*.

# Uso:
# ./scripts/setup_local_db.sh [DB_USER] [DB_PASSWORD] [DB_NAME]
# Si no se pasan argumentos, usa valores por defecto.

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCHEMA_FILE="$REPO_ROOT/apex-unsis-snkc.sql"
SEED_FILE="$REPO_ROOT/scripts/seed_carreras.sql"
ENV_FILE="$REPO_ROOT/.env"

DB_USER="${1:-apex_user}"
DB_PASSWORD="${2:-apex_pass}"
DB_NAME="${3:-apex_db}"
DB_HOST="localhost"
DB_PORT="5432"
APP_ENV="development"

# Check psql
if ! command -v psql >/dev/null 2>&1; then
  echo "Error: psql no está instalado o no está en PATH. Instala PostgreSQL client o usa otra máquina con psql." >&2
  exit 1
fi

echo "Usando valores: DB_USER=$DB_USER DB_NAME=$DB_NAME DB_HOST=$DB_HOST DB_PORT=$DB_PORT"

# Function to run psql as postgres-superuser when needed
run_psql_as_postgres() {
  local sql="$1"
  if sudo -n true 2>/dev/null; then
    sudo -u postgres psql -v ON_ERROR_STOP=1 -c "$sql"
  else
    # intentar ejecutar psql como usuario postgres (requiere permisos)
    echo "Advertencia: no se pudo usar sudo sin password; intentando ejecutar psql como 'postgres' con sudo interactivo..."
    sudo -u postgres psql -v ON_ERROR_STOP=1 -c "$sql"
  fi
}

# 1) Crear rol/usuario (si no existe)
echo "Creando rol (si no existe) y asignando contraseña..."
run_psql_as_postgres "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '$DB_USER') THEN CREATE ROLE \"$DB_USER\" WITH LOGIN PASSWORD '$DB_PASSWORD'; ELSE ALTER ROLE \"$DB_USER\" WITH PASSWORD '$DB_PASSWORD'; END IF; END\$\$;"

# 2) Crear base de datos (si no existe) y asignar owner
echo "Creando base de datos (si no existe) y asignando propietario..."
if sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'" | grep -q 1; then
  echo "La base de datos '$DB_NAME' ya existe."
else
  echo "Creando base de datos '$DB_NAME'..."
  run_psql_as_postgres "CREATE DATABASE \"$DB_NAME\" OWNER \"$DB_USER\";"
fi

# 3) Cargar esquema
if [ -f "$SCHEMA_FILE" ]; then
  echo "Cargando esquema desde $SCHEMA_FILE ..."
  PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -v ON_ERROR_STOP=1 -f "$SCHEMA_FILE"
else
  echo "Error: no se encontró el archivo de esquema $SCHEMA_FILE" >&2
  exit 1
fi

# 4) Cargar seed (si existe)
if [ -f "$SEED_FILE" ]; then
  echo "Cargando datos de ejemplo desde $SEED_FILE ..."
  PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -v ON_ERROR_STOP=1 -f "$SEED_FILE"
else
  echo "No se encontró $SEED_FILE — saltando seed." 
fi

# 5) Generar .env en la raíz del repo (sobrescribe si existe)
cat > "$ENV_FILE" <<EOF
# Archivo .env generado por scripts/setup_local_db.sh
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
DB_NAME=$DB_NAME
APP_ENV=$APP_ENV
EOF

echo "Archivo .env creado en $ENV_FILE"

echo "Configuración completada. Puedes arrancar la app con:\n  source venv/bin/activate\n  uvicorn app.main:app --reload"

echo "Prueba el endpoint: http://127.0.0.1:8000/carreras"

# Arrancar automáticamente el servidor si existe un virtualenv en ./venv
VENV_ACTIVATE="$REPO_ROOT/venv/bin/activate"
if [ -f "$VENV_ACTIVATE" ]; then
  echo "Entorno virtual detectado en ./venv — arrancando la app automáticamente en segundo plano..."
  # Activar venv en un subshell y lanzar uvicorn en background, redirigiendo logs
  ( source "$VENV_ACTIVATE" && nohup uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload > "$REPO_ROOT/uvicorn.log" 2>&1 & )
  sleep 1
  echo "Uvicorn arrancado (logs en $REPO_ROOT/uvicorn.log). Espera unos segundos y prueba: curl http://127.0.0.1:8000/carreras"
else
  echo "No se detectó un entorno virtual en ./venv. Para iniciar el servidor:"
  echo "  source venv/bin/activate && uvicorn app.main:app --reload"
fi

exit 0
