CREATE TABLE carreras (
  id_carrera VARCHAR(20) PRIMARY KEY,
  nombre_carrera VARCHAR(100)
);

-- Script de seed: inserta datos de ejemplo de forma idempotente.
-- Solo inserta filas; asume que las tablas ya existen (creadas por apex-unsis-snkc.sql).

-- Insertar carreras (usa ON CONFLICT DO NOTHING para evitar duplicados)
INSERT INTO carreras (id_carrera, nombre_carrera) VALUES
  ('CARR_ISW', 'Ingeniería de Software'),
  ('CARR_IEL', 'Ingeniería Electrónica'),
  ('CARR_MAT', 'Matemáticas Aplicadas')
ON CONFLICT (id_carrera) DO NOTHING;

-- Insertar periodos académicos
INSERT INTO periodos_academicos (id_periodo, nombre_periodo) VALUES
  ('PER_2025_1', '2025-1'),
  ('PER_2025_2', '2025-2')
ON CONFLICT (id_periodo) DO NOTHING;

-- Tipos de evaluación
INSERT INTO tipos_de_evaluacion (id_evaluacion, nombre_evaluacion) VALUES
  ('EVAL_ORAL', 'Oral'),
  ('EVAL_ESCRITO', 'Escrito')
ON CONFLICT (id_evaluacion) DO NOTHING;

-- Algunas materias
INSERT INTO materias (id_materia, nombre_materia) VALUES
  ('MAT_ISW_001', 'Programación I'),
  ('MAT_ISW_002', 'Estructuras de Datos')
ON CONFLICT (id_materia) DO NOTHING;

-- Profesores
INSERT INTO profesores (id_profesor, nombre_profesor, is_disable) VALUES
  ('PROF_001', 'Dr. Ana López', FALSE),
  ('PROF_002', 'Ing. Carlos Pérez', FALSE)
ON CONFLICT (id_profesor) DO NOTHING;

-- Aulas
INSERT INTO aulas (id_aula, nombre_aula, capacidad, is_disable) VALUES
  ('AULA_101', 'Aula 101', 40, FALSE),
  ('AULA_102', 'Aula 102', 30, FALSE)
ON CONFLICT (id_aula) DO NOTHING;

-- Grupos escolares
INSERT INTO grupos_escolares (id_grupo, nombre_grupo, numero_alumnos, id_carrera) VALUES
  ('GRP_ISW_A', 'ISW - Grupo A', 30, 'CARR_ISW'),
  ('GRP_ISW_B', 'ISW - Grupo B', 28, 'CARR_ISW')
ON CONFLICT (id_grupo) DO NOTHING;

-- Nota: el resto de tablas pueden poblarse según sea necesario.

-- Resultado: tras ejecutar este script, /carreras debería devolver filas si la tabla existe y está vacía

