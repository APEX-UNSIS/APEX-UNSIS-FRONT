# Scripts de base de datos

Contenido:

- `setup_local_db.sh` — Script que automatiza la creación del rol/usuario, la base de datos, carga el esquema (`apex-unsis-snkc.sql`) y ejecuta `scripts/seed_carreras.sql` si existe. También genera un archivo `.env` en la raíz del repositorio.
- `seed_carreras.sql` — Script que crea e inserta datos de ejemplo en la tabla `carreras` (ya incluido en este repo).

Cómo usar `setup_local_db.sh` (ejemplo):

```bash
# desde la raíz del repo
# dar permiso de ejecución (si aún no lo tiene)
chmod +x scripts/setup_local_db.sh

# ejecutar con argumentos: DB_USER DB_PASSWORD DB_NAME
./scripts/setup_local_db.sh mi_usuario mi_contraseña apex_db

# o sin argumentos (usa valores por defecto: apex_user/apex_pass/apex_db)
./scripts/setup_local_db.sh
```

Qué hace el script:
- Crea (o actualiza) el rol con la contraseña dada.
- Crea la base de datos y asigna el owner.
- Ejecuta `apex-unsis-snkc.sql` para crear las tablas.
- Ejecuta `scripts/seed_carreras.sql` si existe para poblar `carreras`.
- Crea/actualiza `.env` con las variables DB_*.

Notas:
- El script usa `sudo -u postgres` para ejecutar comandos de administración; te pedirá tu password si tu sistema lo requiere.
- Requiere `psql` en el PATH.
- No usa Docker — está pensado para un entorno con PostgreSQL ya instalado en localhost.
