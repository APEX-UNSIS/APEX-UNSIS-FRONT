CREATE TABLE carreras (
  id_carrera VARCHAR(20) PRIMARY KEY,
  nombre_carrera VARCHAR(100)
);

CREATE TABLE periodos_academicos (
  id_periodo VARCHAR(20) PRIMARY KEY,
  nombre_periodo VARCHAR(30)
);

CREATE TABLE tipos_de_evaluacion (
  id_evaluacion VARCHAR(20) PRIMARY KEY,
  nombre_evaluacion VARCHAR(30)
);

CREATE TABLE grupos_escolares (
  id_grupo VARCHAR(20) PRIMARY KEY,
  nombre_grupo VARCHAR(20),
  numero_alumnos INT,
  id_carrera VARCHAR(20) REFERENCES carreras(id_carrera)
);

CREATE TABLE materias (
  id_materia VARCHAR(20) PRIMARY KEY,
  nombre_materia VARCHAR(50)
);

CREATE TABLE profesores (
  id_profesor VARCHAR(20) PRIMARY KEY,
  nombre_profesor VARCHAR(60),
  is_disable BOOLEAN
);

CREATE TABLE aulas (
  id_aula VARCHAR(20) PRIMARY KEY,
  nombre_aula VARCHAR(50),
  capacidad INT,
  is_disable BOOLEAN
);

CREATE TABLE horarios_regulares_de_clase (
  id_horario_clase VARCHAR(20) PRIMARY KEY,
  id_periodo VARCHAR(20) REFERENCES periodos_academicos(id_periodo),
  id_materia VARCHAR(20) REFERENCES materias(id_materia),
  id_grupo VARCHAR(20) REFERENCES grupos_escolares(id_grupo),
  id_profesor VARCHAR(20) REFERENCES profesores(id_profesor),
  id_aula VARCHAR(20) REFERENCES aulas(id_aula),
  dia_semana INT,
  hora_inicio TIME,
  hora_fin TIME
);

CREATE TABLE permisos_sinodales_por_materia (
  id_regla VARCHAR(20) PRIMARY KEY,
  id_profesor VARCHAR(20) REFERENCES profesores(id_profesor),
  id_materia VARCHAR(20) REFERENCES materias(id_materia)
);

CREATE TABLE ventanas_de_aplicacion_por_periodo (
  id_ventana VARCHAR(20) PRIMARY KEY,
  id_periodo VARCHAR(20) REFERENCES periodos_academicos(id_periodo),
  id_evaluacion VARCHAR(20) REFERENCES tipos_de_evaluacion(id_evaluacion),
  fecha_inicio_examenes DATE,
  fecha_fin_examenes DATE
);

CREATE TABLE solicitudes_de_examen (
  id_horario VARCHAR(20) PRIMARY KEY,
  id_periodo VARCHAR(20) REFERENCES periodos_academicos(id_periodo),
  id_evaluacion VARCHAR(20) REFERENCES tipos_de_evaluacion(id_evaluacion),
  id_materia VARCHAR(20) REFERENCES materias(id_materia),
  fecha_examen DATE,
  hora_inicio TIME,
  hora_fin TIME,
  estado INT DEFAULT 0,
  motivo_rechazo VARCHAR(255),
  is_manualmente_editado BOOLEAN DEFAULT FALSE
);

CREATE TABLE grupos_por_solicitud_de_examen (
  id_examen_grupo VARCHAR(20) PRIMARY KEY,
  id_horario VARCHAR(20) REFERENCES solicitudes_de_examen(id_horario),
  id_grupo VARCHAR(20) REFERENCES grupos_escolares(id_grupo)
);

CREATE TABLE asignacion_aulas_y_aplicadores (
  id_examen_aula VARCHAR(20) PRIMARY KEY,
  id_horario VARCHAR(20) REFERENCES solicitudes_de_examen(id_horario),
  id_aula VARCHAR(20) REFERENCES aulas(id_aula),
  id_profesor_aplicador VARCHAR(20) REFERENCES profesores(id_profesor)
);

CREATE TABLE asignacion_sinodales (
  id_examen_sinodal VARCHAR(20) PRIMARY KEY,
  id_horario VARCHAR(20) REFERENCES solicitudes_de_examen(id_horario),
  id_profesor VARCHAR(20) REFERENCES profesores(id_profesor)
);